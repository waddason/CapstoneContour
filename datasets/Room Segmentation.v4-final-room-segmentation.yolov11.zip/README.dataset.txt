# Room Segmentation > Final-Room-Segmentation
https://universe.roboflow.com/nirwana/room-segmentation-o7iga

Provided by a Roboflow user
License: CC BY 4.0

